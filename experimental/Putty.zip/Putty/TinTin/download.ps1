Copy-Item -Path C:\Putty\TinTin\ttng\bundles\ConfigManager\Profiles -Destination C:\Putty\TinTin\Profiles -Recurse
Remove-Item -Recurse C:\Putty\TinTin\ttng

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -uri https://github.com/eldakar/ttng/archive/beta.zip -OutFile "C:\Putty\TinTin\file.zip"


Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::ExtractToDirectory("C:\Putty\TinTin\file.zip", "C:\Putty\TinTin")

New-Item -ItemType directory -Path C:\Putty\TinTin\ttng
Copy-Item -Path C:\Putty\TinTin\bin\* -Destination C:\Putty\TinTin\ttng -Recurse
Copy-Item -Path C:\Putty\TinTin\ttng-beta\* -Destination C:\Putty\TinTin\ttng -Recurse
Copy-Item -Path C:\Putty\TinTin\Profiles -Destination C:\Putty\TinTin\ttng\bundles\ConfigManager\Profiles -Recurse

Remove-Item -Recurse C:\Putty\TinTin\ttng-beta
Remove-Item C:\Putty\TinTin\file.zip
Remove-Item -Recurse C:\Putty\TinTin\Profiles
